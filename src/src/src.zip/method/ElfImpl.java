package src.method;

import java.awt.*;

/**
 * 被触发的函数声明
 */
public class ElfImpl {
    private Elf elf;

    public ElfImpl() throws AWTException {
        this.elf = new Elf();
    }

    // 测试函数
    public void test() {
        elf.nest(Elf.E_ALT, Elf.E_TAB);
    }
}
